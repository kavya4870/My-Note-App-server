require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const Note = require("./models/Note");

const app = express();
app.use(cors());
app.use(express.json());
// Home route
app.get("/", (req, res) => {
  res.send("API Running ✔");
});


// Connect to MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✔ MongoDB Connected"))
  .catch(err => console.error("❌ MongoDB Error:", err));



app.get("/notes", async (req, res) => {
  const notes = await Note.find().sort({ createdAt: -1 });
  res.json(notes);
});

// POST a new note
app.post("/notes", async (req, res) => {
  const note = await Note.create({ text: req.body.text });
  res.status(201).json(note);
});

// UPDATE a note
app.put("/notes/:id", async (req, res) => {
  const note = await Note.findByIdAndUpdate(
    req.params.id,
    { text: req.body.text, updatedAt: new Date() },
    { new: true }
  );
  
  res.json(note);
});

// DELETE a note
app.delete("/notes/:id", async (req, res) => {
  await Note.findByIdAndDelete(req.params.id);
  res.json({ message: "Note deleted" });
});

app.listen(5000, () => {
  console.log("✔ Server running at: http://localhost:5000");
});
