import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";

const API_URL = "http://localhost:5000/notes";


interface Note {
  _id: string;
  text: string;
  createdAt: string;
  updatedAt: string;
}

export default function App() {
  const { toast } = useToast();
  const [notes, setNotes] = useState<Note[]>([]);
  const [text, setText] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  // Pagination
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  // Theme (dark/light)
  const [theme, setTheme] = useState<"light" | "dark">(
    (localStorage.getItem("theme") as "light" | "dark") || "light"
  );

  // Load notes
  const fetchNotes = async () => {
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      setNotes(data);
    } catch {
      toast({ title: "Failed to load notes" });
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  // Apply theme + save
  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    localStorage.setItem("theme", theme);
  }, [theme]);

  // Save note (Add or Edit)
  const handleSave = async () => {
    if (!text.trim()) {
      toast({ title: "Note cannot be empty" });
      return;
    }

    try {
      if (editId) {
        await fetch(`${API_URL}/${editId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        toast({ title: "Note updated" });
      } else {
        await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text }),
        });
        toast({ title: "Note added" });
      }

      setText("");
      setEditId(null);
      fetchNotes();
      setPage(1);
    } catch {
      toast({ title: "Save failed" });
    }
  };

  // Delete note
  const handleDelete = async (id: string) => {
    if (!confirm("Delete this note?")) return;
    await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    toast({ title: "Note deleted" });
    fetchNotes();
  };

  // Load note into textbox for editing
  const handleEdit = (note: Note) => {
    setText(note.text);
    setEditId(note._id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // SEARCH filter
  const filtered = useMemo(
    () =>
      notes.filter((n) =>
        n.text.toLowerCase().includes(search.toLowerCase())
      ),
    [notes, search]
  );

  // Pagination values
  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  useEffect(() => {
    if (page > totalPages) setPage(totalPages);
  }, [totalPages, page]);

  const paginatedNotes = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page, pageSize]);

  return (
    <div className="p-6 max-w-4xl mx-auto min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors">
      
      {/* Header */}
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-sky-600 dark:text-sky-400">
          My Notes
        </h1>

        <div className="flex items-center gap-3">
          <Input
            placeholder="Search notes..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="hidden sm:block w-64"
          />

          <Button variant="outline" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            {theme === "dark" ? "Light" : "Dark"}
          </Button>
        </div>
      </header>

      {/* Mobile search */}
      <div className="sm:hidden mb-4">
        <Input
          placeholder="Search notes..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
        />
      </div>

      {/* Add / Edit note */}
      <Card className="mb-6 shadow">
        <CardHeader>
          <CardTitle>{editId ? "Edit Note" : "Add Note"}</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Write your note here..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="mb-3"
          />

          <div className="flex gap-2">
            <Button onClick={handleSave} className="flex-1">
              {editId ? "Update Note" : "Add Note"}
            </Button>

            {editId && (
              <Button
                variant="ghost"
                onClick={() => {
                  setEditId(null);
                  setText("");
                }}
              >
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Notes list */}
      <div>
        {paginatedNotes.length === 0 ? (
          <p className="text-center text-gray-500 dark:text-gray-400">
            No notes found
          </p>
        ) : (
          <div className="grid gap-4">
            {paginatedNotes.map((note) => (
              <Card key={note._id} className="shadow">
                <CardContent className="p-4">

                  {/* Note text */}
                  <p className="mb-3 text-gray-900 dark:text-gray-100">
                    {note.text}
                  </p>

                  {/* BEAUTIFUL TIMESTAMPS (Modern Icon Style) */}
                  <div className="text-xs text-gray-500 dark:text-gray-400 flex flex-col gap-1 mt-2">

                    {/* Created */}
                    <div className="flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 text-blue-500" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6l4 2m6-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>
                        Created: {new Date(note.createdAt).toLocaleString()}
                      </span>
                    </div>

                    {/* Updated */}
                    <div className="flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687 1.688M19.49 6.293l-9.879 9.88-4.242 1.06 1.06-4.243 9.88-9.88z" />
                      </svg>
                      <span>
                        Updated: {new Date(note.updatedAt).toLocaleString()}
                      </span>
                    </div>

                  </div>

                  {/* Buttons */}
                  <div className="flex gap-2 mt-4">
                    <Button variant="secondary" onClick={() => handleEdit(note)}>
                      Edit
                    </Button>

                    <Button variant="destructive" onClick={() => handleDelete(note._id)}>
                      Delete
                    </Button>
                  </div>

                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between mt-6 gap-3">
        <div className="flex items-center gap-2">
          <Button variant="ghost" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            Prev
          </Button>

          <span className="px-2">
            Page <strong>{page}</strong> / {totalPages}
          </span>

          <Button variant="ghost" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
            Next
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-sm">Items:</label>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
            className="border rounded px-2 py-1 dark:bg-slate-800 dark:border-slate-700"
          >
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={20}>20</option>
          </select>
        </div>
      </div>

    </div>
  );
}
