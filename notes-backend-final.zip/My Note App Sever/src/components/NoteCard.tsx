import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";

interface NoteCardProps {
  id: string;
  content: string;
  createdAt: string;
  onEdit: (id: string, content: string) => void;
  onDelete: (id: string) => void;
}

export const NoteCard = ({ id, content, createdAt, onEdit, onDelete }: NoteCardProps) => {
  return (
    <Card className="p-4 shadow-card hover:shadow-card-hover transition-all duration-200 animate-in fade-in slide-in-from-bottom-2">
      <div className="flex flex-col gap-3">
        <p className="text-sm text-foreground whitespace-pre-wrap break-words min-h-[60px]">
          {content}
        </p>
        <div className="flex items-center justify-between pt-2 border-t border-border">
          <span className="text-xs text-muted-foreground">
            {new Date(createdAt).toLocaleDateString('en-US', { 
              month: 'short', 
              day: 'numeric',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </span>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(id, content)}
              className="h-8 w-8 p-0 hover:bg-accent hover:text-accent-foreground"
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(id)}
              className="h-8 w-8 p-0 hover:bg-destructive/10 hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};
