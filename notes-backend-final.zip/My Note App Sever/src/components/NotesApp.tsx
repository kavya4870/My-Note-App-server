import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { NoteCard } from "./NoteCard";
import { useToast } from "@/hooks/use-toast";
import { Plus, Save } from "lucide-react";

interface Note {
  id: string;
  content: string;
  createdAt: string;
}

const STORAGE_KEY = "notes-app-data";

export const NotesApp = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const { toast } = useToast();

  // Load notes from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setNotes(JSON.parse(stored));
      } catch (error) {
        console.error("Failed to parse stored notes:", error);
      }
    }
  }, []);

  // Save notes to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  }, [notes]);

  const handleAddNote = () => {
    if (!inputValue.trim()) {
      toast({
        title: "Empty note",
        description: "Please enter some text for your note.",
        variant: "destructive",
      });
      return;
    }

    if (editingId) {
      // Update existing note
      setNotes(notes.map(note => 
        note.id === editingId 
          ? { ...note, content: inputValue.trim() }
          : note
      ));
      toast({
        title: "Note updated",
        description: "Your note has been successfully updated.",
      });
      setEditingId(null);
    } else {
      // Add new note
      const newNote: Note = {
        id: Date.now().toString(),
        content: inputValue.trim(),
        createdAt: new Date().toISOString(),
      };
      setNotes([newNote, ...notes]);
      toast({
        title: "Note added",
        description: "Your note has been successfully saved.",
      });
    }
    
    setInputValue("");
  };

  const handleEdit = (id: string, content: string) => {
    setEditingId(id);
    setInputValue(content);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = (id: string) => {
    setNotes(notes.filter(note => note.id !== id));
    if (editingId === id) {
      setEditingId(null);
      setInputValue("");
    }
    toast({
      title: "Note deleted",
      description: "Your note has been removed.",
    });
  };

  const handleCancel = () => {
    setEditingId(null);
    setInputValue("");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-5xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
            My Notes
          </h1>
          <p className="text-muted-foreground">
            Capture your thoughts and ideas
          </p>
        </div>

        {/* Input Section */}
        <div className="mb-8 bg-card rounded-lg shadow-card p-6">
          <Textarea
            placeholder="Write your note here..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="min-h-[120px] mb-4 resize-none focus-visible:ring-primary"
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                handleAddNote();
              }
            }}
          />
          <div className="flex gap-2 justify-end">
            {editingId && (
              <Button
                variant="outline"
                onClick={handleCancel}
              >
                Cancel
              </Button>
            )}
            <Button
              onClick={handleAddNote}
              className="bg-gradient-primary hover:opacity-90 transition-opacity"
            >
              {editingId ? (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Update Note
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Note
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Notes Grid */}
        {notes.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg mb-2">No notes yet</p>
            <p className="text-muted-foreground text-sm">
              Start by adding your first note above
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {notes.map((note) => (
              <NoteCard
                key={note.id}
                {...note}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
