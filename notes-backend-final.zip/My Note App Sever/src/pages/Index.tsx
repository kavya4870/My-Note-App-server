import { NotesApp } from "@/components/NotesApp";

const Index = () => {
  return <NotesApp />;
};

export default Index;
